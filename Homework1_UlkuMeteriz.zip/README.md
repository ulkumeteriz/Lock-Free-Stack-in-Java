**CAP6616 Homework Assignment 1**

In this homework, a lock-free stack is implemented using JAVA8.

**To compile and run by using Makefile:**
	
	$ make
	$ make run
	
**To compile and run manually:**
	
	$ javac *.java
	$ java MP
